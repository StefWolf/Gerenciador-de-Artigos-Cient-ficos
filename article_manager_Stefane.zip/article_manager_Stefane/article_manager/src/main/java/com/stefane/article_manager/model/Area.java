package com.stefane.article_manager.model;

public class Area {
    private Long id;
    private String nome;
    private Integer qtdArtigosRegistrados = 0;

    public Area() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getQtdArtigosRegistrados() {
        return qtdArtigosRegistrados;
    }

    public void setQtdArtigosRegistrados(Integer qtdArtigosRegistrados) {
        this.qtdArtigosRegistrados = qtdArtigosRegistrados;
    }
}
