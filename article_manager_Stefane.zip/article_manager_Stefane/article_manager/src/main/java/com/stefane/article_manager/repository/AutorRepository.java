package com.stefane.article_manager.repository;

import com.stefane.article_manager.model.Autor;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class AutorRepository {

    private Map<Long, Autor> banco = new HashMap<>();
    private Long sequence = 1L;

    public Autor salvar(Autor autor) {
        if (autor.getId() == null) {
            autor.setId(sequence++);
        }
        banco.put(autor.getId(), autor);
        return autor;
    }

    public Optional<Autor> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }

    public List<Autor> listarTodos() {
        return new ArrayList<>(banco.values());
    }

    public void deletar(Long id) {
        banco.remove(id);
    }
}