package com.stefane.article_manager.model;

import com.stefane.article_manager.enums.StatusArtigo;
import java.util.List;

public class Artigo {
    private Long id;
    private String nome;
    private Integer ano;
    private List<Autor> autores;
    private Periodico periodico;
    private Area area;
    private String doi;
    private String observacoes;
    private StatusArtigo status;

    public Artigo() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public Integer getAno() {
        return ano;
    }

    public Periodico getPeriodico() {
        return periodico;
    }

    public Area getArea() {
        return area;
    }

    public String getDoi() {
        return doi;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public StatusArtigo getStatus() {
        return status;
    }
    
    public List<Autor> getAutores() {
        return autores;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }

    public void setPeriodico(Periodico periodico) {
        this.periodico = periodico;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public void setStatus(StatusArtigo status) {
        this.status = status;
    }

    
}
