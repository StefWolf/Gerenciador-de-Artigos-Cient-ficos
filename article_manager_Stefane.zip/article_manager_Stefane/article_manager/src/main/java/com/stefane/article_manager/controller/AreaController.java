package com.stefane.article_manager.controller;

import com.stefane.article_manager.dto.*;
import com.stefane.article_manager.model.Area;
import com.stefane.article_manager.repository.*;
import com.stefane.article_manager.exception.RegraNegocioException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/areas")
public class AreaController {

    @Autowired
    private AreaRepository areaRepository;

    @Autowired
    private ArtigoRepository artigoRepository;

    @PostMapping
    public ResponseEntity<?> criar(@Valid @RequestBody AreaRequestDTO dto) {

        Area area = new Area();
        area.setNome(dto.getNome());

        areaRepository.salvar(area);

        return ResponseEntity.ok("Área criada com sucesso");
    }

    @GetMapping
    public ResponseEntity<List<AreaResponseDTO>> listar() {

        List<AreaResponseDTO> lista = areaRepository.listarTodos()
                .stream()
                .map(a -> {
                    AreaResponseDTO dto = new AreaResponseDTO();
                    dto.setNome(a.getNome());
                    dto.setQtdArtigosRegistrados(a.getQtdArtigosRegistrados());
                    return dto;
                }).collect(Collectors.toList());

        return ResponseEntity.ok(lista);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id,
                                       @Valid @RequestBody AreaRequestDTO dto) {

        Area area = areaRepository.buscarPorId(id)
                .orElseThrow(() -> new RegraNegocioException("Área não encontrada"));

        area.setNome(dto.getNome());

        areaRepository.salvar(area);

        return ResponseEntity.ok("Área atualizada");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {

        areaRepository.buscarPorId(id)
                .orElseThrow(() -> new RegraNegocioException("Área não encontrada"));

        if (artigoRepository.existePorAreaId(id)) {
            throw new RegraNegocioException("Área possui artigos vinculados");
        }

        areaRepository.deletar(id);

        return ResponseEntity.ok("Área deletada");
    }
}