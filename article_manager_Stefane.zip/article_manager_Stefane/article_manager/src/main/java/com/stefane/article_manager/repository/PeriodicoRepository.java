package com.stefane.article_manager.repository;

import com.stefane.article_manager.model.Periodico;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class PeriodicoRepository {

    private Map<Long, Periodico> banco = new HashMap<>();
    private Long sequence = 1L;

    public Periodico salvar(Periodico periodico) {
        if (periodico.getId() == null) {
            periodico.setId(sequence++);
        }
        banco.put(periodico.getId(), periodico);
        return periodico;
    }

    public Optional<Periodico> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }

    public List<Periodico> listarTodos() {
        return new ArrayList<>(banco.values());
    }

    public void deletar(Long id) {
        banco.remove(id);
    }
}