package com.stefane.article_manager.repository;

import com.stefane.article_manager.model.Artigo;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ArtigoRepository {

    private Map<Long, Artigo> banco = new HashMap<>();
    private Long sequence = 1L;

    public Artigo salvar(Artigo artigo) {
        if (artigo.getId() == null) {
            artigo.setId(sequence++);
        }
        banco.put(artigo.getId(), artigo);
        return artigo;
    }

    public Optional<Artigo> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }

    public List<Artigo> listarTodos() {
        return new ArrayList<>(banco.values());
    }

    public void deletar(Long id) {
        banco.remove(id);
    }

    public List<Artigo> buscarPorAno(Integer ano) {
        return banco.values().stream()
                .filter(a -> a.getAno().equals(ano))
                .toList();
    }

    public List<Artigo> buscarPorStatus(String status) {
        return banco.values().stream()
                .filter(a -> a.getStatus().name().equalsIgnoreCase(status))
                .toList();
    }

    public List<Artigo> buscarPorArea(String nomeArea) {
        return banco.values().stream()
                .filter(a -> a.getArea().getNome().equalsIgnoreCase(nomeArea))
                .toList();
    }

    public List<Artigo> buscarPorAutor(String nomeAutor) {
        return banco.values().stream()
                .filter(a -> a.getAutores().stream()
                        .anyMatch(autor -> autor.getNome().equalsIgnoreCase(nomeAutor)))
                .toList();
    }

    public boolean existePorDoi(String doi) {
        return banco.values().stream()
                .anyMatch(a -> doi != null && doi.equals(a.getDoi()));
    }

    public boolean existePorAreaId(Long areaId) {
    return banco.values().stream()
        .anyMatch(a -> a.getArea().getId().equals(areaId));
}

    public boolean existePorAutorId(Long autorId) {
        return banco.values().stream()
            .anyMatch(a -> a.getAutores().stream()
                .anyMatch(autor -> autor.getId().equals(autorId)));
    }

    public boolean existePorPeriodicoId(Long periodicoId) {
        return banco.values().stream()
            .anyMatch(a -> a.getPeriodico().getId().equals(periodicoId));
    }
}