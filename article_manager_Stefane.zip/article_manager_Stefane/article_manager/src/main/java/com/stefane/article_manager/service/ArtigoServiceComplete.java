package com.stefane.article_manager.service;

import com.stefane.article_manager.dto.*;
import com.stefane.article_manager.model.*;
import com.stefane.article_manager.repository.*;
import com.stefane.article_manager.exception.RegraNegocioException;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Qualifier("complete")
public class ArtigoServiceComplete implements ArtigoService {

    @Autowired
    private ArtigoRepository artigoRepository;

    @Autowired
    private AutorRepository autorRepository;

    @Autowired
    private AreaRepository areaRepository;

    @Autowired
    private PeriodicoRepository periodicoRepository;

    @Override
    public ArtigoResponseDTO criar(ArtigoRequestDTO dto) {

        Artigo artigo = montarArtigo(dto);

        artigoRepository.salvar(artigo);

        return converterParaDTO(artigo);
    }

    @Override
    public List<ArtigoResponseDTO> listar() {
        return artigoRepository.listarTodos()
                .stream()
                .map(this::converterParaDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ArtigoResponseDTO buscarPorId(Long id) {
        Artigo artigo = artigoRepository.buscarPorId(id)
                .orElseThrow(() -> new RegraNegocioException("Artigo não encontrado"));

        return converterParaDTO(artigo);
    }

    @Override
    public ArtigoResponseDTO atualizar(Long id, ArtigoRequestDTO dto) {

        Artigo artigo = artigoRepository.buscarPorId(id)
                .orElseThrow(() -> new RegraNegocioException("Artigo não encontrado"));

        Artigo atualizado = montarArtigo(dto);
        atualizado.setId(id);

        artigoRepository.salvar(atualizado);

        return converterParaDTO(atualizado);
    }

    @Override
    public void deletar(Long id) {
        artigoRepository.buscarPorId(id)
                .orElseThrow(() -> new RegraNegocioException("Artigo não encontrado"));

        artigoRepository.deletar(id);
    }

    private Artigo montarArtigo(ArtigoRequestDTO dto) {

        List<Autor> autores = dto.getAutoresIds().stream()
                .map(id -> autorRepository.buscarPorId(id)
                        .orElseThrow(() -> new RegraNegocioException("Autor não encontrado: " + id)))
                .toList();

        Area area = areaRepository.buscarPorId(dto.getAreaId())
                .orElseThrow(() -> new RegraNegocioException("Área não encontrada"));

        Periodico periodico = periodicoRepository.buscarPorId(dto.getPeriodicoId())
                .orElseThrow(() -> new RegraNegocioException("Periódico não encontrado"));

        Artigo artigo = new Artigo();
        artigo.setNome(dto.getNome());
        artigo.setAno(dto.getAno());
        artigo.setAutores(autores);
        artigo.setArea(area);
        artigo.setPeriodico(periodico);
        artigo.setDoi(dto.getDoi());
        artigo.setObservacoes(dto.getObservacoes());
        artigo.setStatus(dto.getStatus());

        return artigo;
    }

    private ArtigoResponseDTO converterParaDTO(Artigo artigo) {

        ArtigoResponseDTO dto = new ArtigoResponseDTO();

        dto.setNome(artigo.getNome());
        dto.setAno(artigo.getAno());
        dto.setAutores(
                artigo.getAutores().stream()
                        .map(Autor::getNome)
                        .toList()
        );
        dto.setArea(artigo.getArea().getNome());
        dto.setPeriodico(artigo.getPeriodico().getNome());
        dto.setDoi(artigo.getDoi());
        dto.setObservacoes(artigo.getObservacoes());
        dto.setStatus(artigo.getStatus());

        return dto;
    }
}