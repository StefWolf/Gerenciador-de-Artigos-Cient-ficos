package com.stefane.article_manager.repository;

import com.stefane.article_manager.model.Area;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class AreaRepository {

    private Map<Long, Area> banco = new HashMap<>();
    private Long sequence = 1L;

    public Area salvar(Area area) {
        if (area.getId() == null) {
            area.setId(sequence++);
        }
        banco.put(area.getId(), area);
        return area;
    }

    public Optional<Area> buscarPorId(Long id) {
        return Optional.ofNullable(banco.get(id));
    }

    public List<Area> listarTodos() {
        return new ArrayList<>(banco.values());
    }

    public void deletar(Long id) {
        banco.remove(id);
    }
}